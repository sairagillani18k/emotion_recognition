from depthai_sdk import OakCamera, TwoStagePacket, TextPosition
import numpy as np
import cv2
from PyQt5.QtWidgets import QApplication, QLabel, QWidget
from PyQt5.QtCore import QTimer
import os
from PyQt5.QtGui import QIcon, QMovie
from PyQt5.QtGui import QPixmap, QPalette
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
class QuoteWindow(QWidget):
    quote_windows = {}

    def __init__(self, emotion):
        super().__init__()
        self.emotion = emotion
        self.setWindowIcon(QIcon('logo.png'))

        palette = self.palette()
        pixmap = QPixmap('background.jpg')
        palette.setBrush(QPalette.Window, QBrush(pixmap))
        self.setPalette(palette)

        self.ChangeBTN = QPushButton("Next Quote")
        self.ChangeBTN.clicked.connect(self.keyPress)
        self.ChangeBTN.setStyleSheet("border-radius: 15px; background-color: #2196f3; color: white; font-weight: bold; font-size: 20px; padding: 10px;")
  
        self.setWindowTitle(f"{emotion.capitalize()} Quotes")
        self.quotes = []
        self.quote_index = 0
        quotes_dir = os.path.join(os.getcwd(), "quotes", emotion)
        for file_name in os.listdir(quotes_dir):
            with open(os.path.join(quotes_dir, file_name), "r") as f:
                self.quotes.extend(f.read().splitlines())

        self.label = QLabel("", self)
        self.label.move(50, 50)
        self.update_quote()

        vbox = QVBoxLayout()
        vbox.addWidget(self.label)
        vbox.addWidget(self.ChangeBTN)
        vbox.setAlignment(Qt.AlignCenter)

        self.setLayout(vbox)

        self.show()
        self.show()

    def update_quote(self):
        quote = self.quotes[self.quote_index]
        self.quote_index = (self.quote_index + 1) % len(self.quotes)
        self.label.setText(f"<font size=6>{quote}</font>")
        self.label.adjustSize()
    def keyPress(self):
        self.update_quote()
    def keyPressEvent(self, event):
        if event.key() == 32:  # Space key
            self.update_quote()

emotions = ['neutral', 'happy', 'sad', 'surprise', 'anger']

app = QApplication([])

with OakCamera() as oak:
    color = oak.create_camera('color')
    det = oak.create_nn('face-detection-retail-0004', color)
    det.config_nn(resize_mode='crop')

    emotion_nn = oak.create_nn('emotions-recognition-retail-0003', input=det)

    def cb(packet: TwoStagePacket, visualizer):
        visible_emotions = set()
        for det, rec in zip(packet.detections, packet.nnData):
            emotion_results = np.array(rec.getFirstLayerFp16())
            emotion_name = emotions[np.argmax(emotion_results)]

            visible_emotions.add(emotion_name)

            if emotion_name not in QuoteWindow.quote_windows:
                QuoteWindow.quote_windows[emotion_name] = QuoteWindow(emotion_name)

            quote_window = QuoteWindow.quote_windows[emotion_name]

            if not quote_window.isVisible():
                quote_window.show()

            visualizer.add_text(emotion_name,
                                bbox=(*det.top_left, *det.bottom_right),
                                position=TextPosition.BOTTOM_RIGHT)

        # Hide quote windows for emotions that are not visible
        for emotion, quote_window in QuoteWindow.quote_windows.items():
            if emotion not in visible_emotions:
                quote_window.hide()

        visualizer.draw(packet.frame)

    oak.visualize(emotion_nn, callback=cb, fps=True)
    oak.visualize(det.out.passthrough)
    oak.start(blocking=True)

app.exec()
